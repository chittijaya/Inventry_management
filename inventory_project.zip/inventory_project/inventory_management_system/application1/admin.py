from django.contrib import admin
from .models import Add_customer
from .models import Category
from .models import brand
from .models import Supplier
from .models import Product
from .models import Purchase
from .models import Manage

# Register your models here.

admin.site.register(Add_customer)
admin.site.register(Category)  
admin.site.register(brand)
admin.site.register(Supplier)
admin.site.register(Product)
admin.site.register(Purchase)
admin.site.register(Manage)

