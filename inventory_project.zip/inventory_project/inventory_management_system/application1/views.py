from django.shortcuts import render,redirect
from django.urls import reverse
from .models import Add_customer
from .models import Category
from .models import brand
from .models import Supplier
from .models import Product
from .models import Purchase
from .models import Manage
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth import authenticate, login as auth_login
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from django.db import models
from django.db.models import Sum,Count,Q
from django.http import HttpResponse



# Create your views here.
@login_required
def Test_case1(request):
    return render(request,"login.html")

def login_page(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        user = authenticate(request, username=email, password=password)
        if user is not None:
            auth_login(request, user)
            messages.success(request, "Login successful")
            return redirect('a')
        else:
            messages.error(request, "Invalid email or password")
            return redirect('login_page')
    else:
        return render(request, "login.html")
    
@login_required    
def Test_case2(request):
    
    products = Product.objects.filter(status=True).annotate(
        inventory_star=Sum('quantity'),
        inventory_rec=Sum('purchase__quantity'),
        inventory_shi=Sum('manage__total_item')
    )
    
    
    product_list = []
    for product in products:
        inventory_star = product.inventory_star or 0
        inventory_rec = product.inventory_rec or 0
        inventory_shi = product.inventory_shi or 0
        inventory_hand = inventory_star + inventory_rec - inventory_shi
        product_data = {
            'id': product.id,
            'name': product.product_name,
            'modal':product.product_model,
            'inventory_star': inventory_star,
            'inventory_rec': inventory_rec,
            'inventory_shi': inventory_shi,
            'inventory_hand': inventory_hand
        }
        product_list.append(product_data)

    # Paginate the product data
    paginator = Paginator(product_list, 5)
    page_number = request.GET.get('page')
    page_obj7 = paginator.get_page(page_number)
    
    context = {
        'page_obj7': page_obj7,
    }
    
    return render(request, 'home.html', context)


@login_required
def Test_case3(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        Address = request.POST.get("address")
        mobile = request.POST.get("mobile")
        balance = request.POST.get("balance")
        print("name",name)
        print("Address",Address)
        print("mobile",mobile)
        print("balance",balance)
        # Create and save the new customer
        Add_customer.objects.create(
            name=name,
            Address=Address,
            mobile=mobile,
            balance=balance
        )
        
    # Retrieve all customers from the database
    data = Add_customer.objects.all()
    
    # Paginate the customer data
    paginator = Paginator(data, 5)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'data':data,
    }
    
    return render(request, "customer.html", context)



         
def update_customer(request,pk):
    edit_customer=Add_customer.objects.get(id=pk)
    
    if request.method=="POST":
        edit_customer.name = request.POST.get("name")
        edit_customer.mobile = request.POST.get("mobile")
        edit_customer.balance = request.POST.get("balance")
        edit_customer.Address = request.POST.get("Address")
        print(request.POST.get("Address"))

        edit_customer.save()
        
        return redirect(reverse('b'))
    context={
        "edit_customer":edit_customer
    }
    return render(request,'customer.html',context)

def delete_customer(request,pk):
    add_customer=Add_customer.objects.get(id=pk)
    add_customer.delete()
    
    return redirect(reverse('b'))

def customersearch(request):
    if request.method == 'GET':
        query = request .GET.get('query')
        if query:
            page_obj= Add_customer.objects.filter(
                Q(name__icontains=query)|
                Q(Address__icontains=query) |
                Q(mobile__icontains=query) |
                Q(balance__icontains=query)         
            )
            return render(request,'customer.html',{'page_obj':page_obj})
        else:
            print('no customer ')
            return render(request,'customer.html')
            

def Test_case4(request):
    # Your view logic here
    if request.method =='POST':
        name = request.POST.get("name")
        save = Category(name=name)
        save.save()
    
    # Retrieve all categories from the database
    data = Category.objects.all()
    
    # Paginate the category data
    paginator = Paginator(data, 5)
    
    # Get the page number from the GET parameters
    page_number = request.GET.get('page')
    
    # Get the page object for the specified page number
    page_obj1 = paginator.get_page(page_number)
    
    context = {
        'page_obj1': page_obj1
    }
    return render(request, 'category.html', context)




def categorysearch(request):
    if request.method == 'GET':
        query = request .GET.get('query')
        if query:
            page_obj1= Category.objects.filter(
                Q(name__icontains=query)
                         
            )
            return render(request,'category.html',{'page_obj1':page_obj1,})
        else:
            print('no category ')
            return render(request,'category.html')


def delete_category(request,pk):
    category=Category.objects.get(id=pk)
    category.delete()
    
    return redirect(reverse('c'))

def update_category(request,pk):
    edit_category=Category.objects.get(id=pk)
    
    if request.method=="POST":
        edit_category.name = request.POST.get("name")
        

        edit_category.save()
        
        return redirect(reverse('c'))
    context={
        "edit_category":edit_category
    }
    return render(request,'category.html',context)


def Test_case5(request):
    if request.method == 'POST':
        category_id = request.POST.get("category")
        brand_name = request.POST.get("brand_name")

        if not category_id:
            return HttpResponse("Category is required", status=400)

        if not brand_name:
            return HttpResponse("Brand name is required", status=400)

        try:
            category = Category.objects.get(id=category_id)
        except Category.DoesNotExist:
            return HttpResponse("Category not found", status=404)

        brand.objects.create(
            brand_name=brand_name,
            category=category
        )
        return redirect('d') 

    categories = Category.objects.all()
    data = brand.objects.all()

    paginator = Paginator(data, 5)
    page_number = request.GET.get('page')
    page_obj2 = paginator.get_page(page_number)

    context = {
        'page_obj2': page_obj2,
        'categories': categories,
        'data': data,
    }

    return render(request, 'brand.html', context)

def brandsearch(request):
    if request.method == 'GET':
        query = request.GET.get('query')
        if query:
            page_obj2=brand.objects.filter(
                Q(brand_name__icontains=query)
                
            )
            return render(request,'brand.html',{'page_obj2':page_obj2})
        else:
            print('no Brand')
            return render(request,'brand.html')

def delete_Brand(request,pk):
    Brand=brand.objects.get(id=pk)
    Brand.delete()
    return redirect(reverse('d'))

def update_Brand(request,pk):
    edit_brand=brand.objects.get(id=pk)
    if request.method=="POST":
        edit_brand.brand_name=request.POST.get("brand_name")
        edit_brand.save()
        return redirect(reverse('d'))
    context={
        "edit_brand":edit_brand
    }
    return render(request,'brand.html',context)

def Test_case6(request):
    if request.method == 'POST':
        name = request.POST.get("name")
        Mobile = request.POST.get("Mobile")
        address = request.POST.get("address")
        

        
        print("name:", name)
        print("Mobile:", Mobile)
        print("address:", address)


        Supplier.objects.create(
            name=name,
            address=address,
            Mobile=Mobile,
        )
        return redirect("e")

    data1 = Supplier.objects.all()
    paginator = Paginator(data1, 5)
    page_number = request.GET.get('page')
    page_obj3 = paginator.get_page(page_number)

    context = {
        'page_obj3': page_obj3,
        'data1': data1,
    }
    return render(request, 'supplier.html', context)

def suppliersearch(request):
    if request.method == 'GET':
        query = request.GET.get('query')
        if query:
            page_obj3=Supplier.objects.filter(
                Q(name__icontains=query)|
                Q(Mobile__icontains=query)|
                Q(address__icontains=query)
                
            )
            return render(request,'supplier.html',{'page_obj3':page_obj3})
        else:
            print('no supplier')
            return render(request,'supplier.html')
        
def delete_supplier(request,pk):
    supplier=Supplier.objects.get(id=pk)
    supplier.delete()
    return redirect(reverse('e'))

def update_supplier(request,pk):
    edit_supplier=Supplier.objects.get(id=pk)
    if request.method=='POST':
        edit_supplier.name=request.POST.get("name")
        edit_supplier.Mobile=request.POST.get("Mobile")
        edit_supplier.address=request.POST.get("address")
        edit_supplier.save()
        return redirect(reverse('e'))
    context={
        "edit_supplier":edit_supplier
    }
    return render(request,'supplier.html',context)

def Test_case7(request):
        if request.method == 'POST':
            category_id = request.POST.get("category")
            brand_id = request.POST.get("Brand")
            product_name = request.POST.get("product_name")
            product_model = request.POST.get("product_model")
            description = request.POST.get("description")
            quantity = request.POST.get("quantity")
            product_price = request.POST.get("product_price")
            product_tax = request.POST.get("product_tax")
            supplier_id = request.POST.get("supplier")
            
            print("category_id:", category_id)
            print("brand_id:", brand_id)
            print("product_name:", product_name)
            print("product_model:", product_model)
            print("description:", description)
            print("quantity:", quantity)
            print("product_price:", product_price)
            print("product_tax:", product_tax)
            print("supplier_id:", supplier_id)
            
        
            if not category_id:
                return HttpResponse("category is required")
            if not brand_id:
                return HttpResponse("Brand is required")
            if not supplier_id:
                return HttpResponse("supplier is required")
            
            try:
                category = Category.objects.get(id=category_id)
            except Category.DoesNotExist:
                return HttpResponse("category not found")
            
            try:
                Brand = brand.objects.get(id=brand_id)
            except brand.DoesNotExist:
                return HttpResponse("brand not found")
            
            try:
                supplier = Supplier.objects.get(id=supplier_id)
            except Supplier.DoesNotExist:
                return HttpResponse("supplier not found")
            
            Product.objects.create(
                category=category,
                Brand=Brand,
                product_name=product_name,
                product_model=product_model,
                description=description,
                quantity=quantity,
                product_price=product_price,
                product_tax=product_tax,
                supplier=supplier
            )
            
            return redirect('f')
        
        categories = Category.objects.all()
        brands = brand.objects.all()
        data = Product.objects.all()
        suppliers = Supplier.objects.all()
        
        paginator = Paginator(data, 5)
        page_number = request.GET.get('page')
        page_obj4 = paginator.get_page(page_number)
        
        context = {
            'page_obj4': page_obj4,
            'categories': categories,
            'Brands': brands,
            'suppliers': suppliers
        }
        return render(request, 'product.html', context)

def productsearch(request):
    if request.method=='GET':
        query=request.GET.get('query')
        if query:
            page_obj4=Product.objects.filter(
                Q(product_name__icontains=query)|
                Q(product_model__icontains=query)|
                Q(description__icontains=query)|
                Q(quantity__icontains=query)|
                Q(product_price__icontains=query)|
                Q(product_tax__icontains=query)
                
            )
            return render(request,'product.html',{'page_obj4':page_obj4})
        else:
            print('no product')
            return render(request,'product.html')

def delete_product(request,pk):
    product=Product.objects.get(id=pk)
    product.delete()
    return redirect(reverse('f'))

def update_product(request,pk):
    edit_product=Product.objects.get(id=pk)
    if request.method=='POST':
        edit_product.product_name=request.POST.get("product_name")
        edit_product.product_model=request.POST.get("product_model")
        edit_product.description=request.POST.get("description")
        edit_product.quality=request.POST.get("quality")
        edit_product.product_price=request.POST.get("product_price")
        edit_product.product_tax=request.POST.get("product_tax")
        edit_product.save()
        return redirect(reverse("f"))
    context={
        "edit_product":edit_product
    }
    return render(request,'product.html',context)

def Test_case8(request):
    if request.method== 'POST':
        product_id = request.POST.get("product")
        quantity= request.POST.get("quantity")
        supplier_id=request.POST.get("supplier")
        
        print("product_id:",product_id)
        print("quantity:",quantity)
        print("supplier_id:",supplier_id)
        
        if not product_id:
            return HttpResponse("product is requried")
        if not quantity:
            return HttpResponse("quantity is  requried")
        if not supplier_id:
            return HttpResponse("supplier is required")
        
        try:
            product=Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return HttpResponse("product not found")
        
        try:
            supplier=Supplier.objects.get(id=supplier_id)
        except Supplier.DoesNotExist:
            return HttpResponse("supplier not found")
        
        Purchase.objects.create(
            product=product,
            quantity=quantity,
            supplier=supplier
        )
        
        return redirect('g')
    
    products=Product.objects.all()
    data=Purchase.objects.all()
    suppliers=Supplier.objects.all()
    
    paginator=Paginator(data,5)
    page_number=request.GET.get('page')
    page_obj5=paginator.get_page(page_number)
    
    context={
        'page_obj5':page_obj5,
        'products':products,
        'suppliers':suppliers
    }
    return render(request,'purchaes.html',context)

def purchasesearch(request):
    if request.method=='GET':
        query=request.GET.get('query')
        if query:
            page_obj5=Product.objects.filter(
                Q(quantity__icontains=query)
            )
            return render(request,'purchaes.html',{'page_obj5':page_obj5})
        else:
            print('no purchase')
            return render(request,'purchaes.html')

def delete_purchase(request,pk):
    purchase=Purchase.objects.get(id=pk)
    purchase.delete()
    return redirect(reverse('g'))

def update_purchase(request,pk):
    edit_purchase=Purchase.objects.get(id=pk)
    if request.method=="POST":
        edit_purchase.quantity=request.POST.get("quantity")
        edit_purchase.save()
        return redirect(reverse('g'))
    context={
        'edit_purchase':edit_purchase
    }
    return render(request,'purchaes.html',context)
        
    
        

def Test_case9(request):
    if request.method== 'POST':
        product_id = request.POST.get("product")
        total_items= request.POST.get('total_items')
        
        add_customer_id= request.POST.get("add_customer")
        
        print("product_id:", product_id)
        print("total_items:", total_items)
        print("add_customer_id:",add_customer_id)
        
        if not product_id:
            return HttpResponse("product is requried")
        if not total_items:
            return HttpResponse("total_items is  requried")
        if not add_customer_id:
            return HttpResponse("add_customer is  requried")
        
        try:
            product=Product.objects.get(id=product_id)
        except Product.DoesNotExist:
            return HttpResponse("product not found")
        try:
            add_customer=Add_customer.objects.get(id=add_customer_id)
        except Add_customer.DoesNotExist:
            return HttpResponse("add_customer not found")
        
        Manage.objects.create(
            product=product,
            total_item=total_items,
            add_customer=add_customer
        )
        return redirect('h')
    
    products=Product.objects.all()
    data=Manage.objects.all()
    add_customers=Add_customer.objects.all()
    
    paginator=Paginator(data,5)
    page_number=request.GET.get('page')
    page_obj6=paginator.get_page(page_number)
    
    context={
        'page_obj6':page_obj6,
        'products':products,
        'add_customers':add_customers
    }    
    return render(request,'orders.html',context)

def ordersearch(request):
    if request.method=='GET':
        query=request.GET.get('query')
        if query:
            page_obj6=Manage.objects.filter(
                Q(total_item__icontains=query)
            )
            return render(request,'orders.html',{'page_obj6':page_obj6})
        else:
            print('no orders')
            return render(request,'orders.html')

def update_order(request,pk):
    edit_order=Manage.objects.get(id=pk)
    if request.method=="POST":
        edit_order.total_items=request.POST.get("total_items")
        edit_order.save()
        return redirect(reverse('h'))
    context={
        'edit_order':edit_order
    }
    return render(request,'orders.html',context)

def delete_orders(request,pk):
    order=Manage.objects.get(id=pk)
    order.delete()
    return redirect(reverse('h'))
        

