"""inventory_management_system URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from application1 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.Test_case1),
    path('', views.login_page, name='login_page'),  # Add this line to ensure accounts/login/ works
    path('a/', views.Test_case2, name='a'),
    path('b/', views.Test_case3, name='b'),
    path('customersearch/', views.customersearch, name='customersearch'),
    path('delete_customer/<int:pk>', views.delete_customer, name='delete_customer'),
    path('update_customer/<int:pk>',views.update_customer,name='update_customer'),
    path('c/', views.Test_case4, name='c'),
    path('categorysearch/', views.categorysearch, name='categorysearch'),
    path('delete_category/<int:pk>', views.delete_category, name='delete_category'),
    path('update_category/<int:pk>', views.update_category, name='update_category'),
    path('d/', views.Test_case5, name='d'),
    path('brandsearch/', views.brandsearch, name='brandsearch'),
    path('delete_Brand/<int:pk>', views.delete_Brand, name='delete_Brand'),
    path('update_Brand/<int:pk>', views.update_Brand, name='update_Brand'),
    path('e/', views.Test_case6, name='e'),
    path('suppliersearch/', views.suppliersearch, name='suppliersearch'),
    path('delete_supplier/<int:pk>', views.delete_supplier, name='delete_supplier'),
    path('update_supplier/<int:pk>', views.update_supplier, name='update_supplier'),
    path('f/', views.Test_case7, name='f'),
    path('productsearch/', views.productsearch, name='productsearch'),
    path('delete_product/<int:pk>', views.delete_product, name='delete_product'),
    path('update_product/<int:pk>', views.update_product, name='update_product'),
    path('g/', views.Test_case8, name='g'),
    path('purchasesearch/', views.purchasesearch, name='purchasesearch'),
    path('delete_purchase/<int:pk>', views.delete_purchase, name='delete_purchase'),
    path('update_purchase/<int:pk>', views.update_purchase, name='update_purchase'),
    path('h/', views.Test_case9, name='h'),
    path('ordersearch/', views.ordersearch, name='ordersearch'),
    path('update_order/<int:pk>', views.update_order, name='update_order'),
    path('delete_orders/<int:pk>', views.delete_orders, name='delete_orders'),

]
